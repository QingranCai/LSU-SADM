import torch
import torch.nn as nn
import torch.nn.functional as F

class ImprovedAttentionGenerator(nn.Module):
    def __init__(self, channels, reduction=8, kernel_size=3):
        super(ImprovedAttentionGenerator, self).__init__()
        out_channels = max(channels // reduction, 1)  # Ensure at least one channel
        self.conv1 = nn.Conv2d(channels, out_channels, 1)
        self.relu = nn.ReLU(inplace=True)
        self.conv2 = nn.Conv2d(out_channels, 1, kernel_size, padding=kernel_size // 2)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        attention = self.conv1(x)
        attention = self.relu(attention)
        attention = self.conv2(attention)
        return self.sigmoid(attention)

class AdaptiveDiagonalEmphasis(nn.Module):
    def __init__(self, channels, strength=10, base_decay=0.8):
        super(AdaptiveDiagonalEmphasis, self).__init__()
        self.attention_generator = ImprovedAttentionGenerator(channels)
        self.strength = nn.Parameter(torch.tensor([strength], dtype=torch.float32))
        self.base_decay = nn.Parameter(torch.tensor([base_decay], dtype=torch.float32))

    def forward(self, x):
        base_attention_map = self.attention_generator(x)
        size = base_attention_map.size(-1)  # 假设输入是正方形
        diagonal_bias = torch.eye(size).to(x.device) * self.strength
        decay_mask = torch.ones(size, size).to(x.device) * self.base_decay
        # 应用广播机制扩展至batch size和channel size
        diagonal_bias = diagonal_bias.unsqueeze(0).unsqueeze(0)  # [1, 1, size, size]
        decay_mask = decay_mask.unsqueeze(0).unsqueeze(0)  # [1, 1, size, size]
        combined_attention_map = base_attention_map * (diagonal_bias + (1 - diagonal_bias) * decay_mask)
        combined_attention_map = F.normalize(combined_attention_map, p=1, dim=(-2, -1))
        return x * combined_attention_map



