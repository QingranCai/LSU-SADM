import torch
import torch.nn as nn
import torch.nn.functional as F



class LocalAttention(nn.Module):
    def __init__(self, num_channels, num_heads, kernel_size=3):
        super(LocalAttention, self).__init__()
        self.channels = num_channels
        self.num_heads = num_heads
        self.kernel_size = kernel_size

        # Multihead Attention
        assert self.channels % self.num_heads == 0, "channels must be divisible by num_heads"
        self.attention = nn.MultiheadAttention(embed_dim=self.channels, num_heads=self.num_heads)

        # Depthwise Convolutions for processing
        self.qconv = nn.Conv2d(self.channels, self.channels, kernel_size=self.kernel_size,
                               padding=self.kernel_size // 2, groups=self.channels)
        self.kconv = nn.Conv2d(self.channels, self.channels, kernel_size=self.kernel_size,
                               padding=self.kernel_size // 2, groups=self.channels)

        # Fully Connected layers for transformations after multiplication
        self.fc1 = nn.Linear(self.channels, self.channels)
        self.swish = nn.SiLU()
        self.fc2 = nn.Linear(self.channels, self.channels)
        self.tanh = nn.Tanh()

    def forward(self, x):
        B, C, H, W = x.shape

        # Preparing input for the MultiheadAttention
        # We flatten the spatial dimensions and treat them as the sequence length
        x_flat = x.contiguous().view(B, C, H * W).transpose(0, 2).transpose(1, 2)  # Shape: (seq_len, batch, embedding_dim)

        # Multihead attention
        attn_output, _ = self.attention(x_flat, x_flat, x_flat)
        attn_output = attn_output.transpose(1, 2).reshape(B, C, H, W)  # Use reshape to ensure the output matches the input dimensions

        # Processing with depthwise convolutions
        q = self.qconv(attn_output)
        k = self.kconv(attn_output)

        # Element-wise multiplication of processed queries and keys
        combined = q * k

        # Flatten before applying linear transformation
        combined_flat = combined.contiguous().reshape(B * H * W, C)

        # Apply linear transformation and activation
        combined_flat = self.fc1(combined_flat)
        combined_flat = self.swish(combined_flat)
        combined_flat = self.fc2(combined_flat)
        combined_flat = self.tanh(combined_flat)

        # Reshape back to the original dimensions
        combined = combined_flat.reshape(B, C, H, W)

        return combined



if __name__ == "__main__":
# Example of initialization and usage
    num_channels = 64
    num_heads = 8
    local_attention_block = LocalAttention(num_channels, num_heads)

    # Dummy input [batch_size, channels, height, width]
    dummy_input = torch.rand(10, num_channels, 32, 32)

    # Forward pass
    output = local_attention_block(dummy_input)
    print("Output shape:", output.shape)  # Expected output shape [10, 64, 32, 32]