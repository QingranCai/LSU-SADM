import torch
import torchvision
import torchvision.transforms as transforms
from torch.utils.data import DataLoader
import matplotlib.pyplot as plt
import numpy as np
import torch.nn as nn
import torch.nn.functional as F
from einops import rearrange, repeat
from torchsummary import summary
import torch.optim as optim
from torch.optim.lr_scheduler import CosineAnnealingLR
import os
import torchmetrics
from torch.cuda.amp import GradScaler, autocast

class GlobalAttention(nn.Module):
    def __init__(self,num_channels, num_heads, pool_size=(2, 2)):
        super(GlobalAttention, self).__init__()
        self.head = num_heads
        self.channels_per_head = num_channels // num_heads
        self.fc = nn.Linear(num_channels, 3 * num_channels)  # Each of Q, K, V has the same dimension as channels
        self.pool = nn.AvgPool2d(pool_size, stride=pool_size)
        self.softmax = nn.Softmax(dim=-1)

    def forward(self, x):
        B, C, H, W = x.shape
        # 全连接层输出q, k, v
        qkv = self.fc(x.view(B, C, H * W).transpose(1, 2))
        qkv = rearrange(qkv, 'b n (three h c) -> three (b h) n c', three=3, h=self.head)
        q, k, v = qkv[0], qkv[1], qkv[2]

        # 将k, v调整维度以进行池化
        k = rearrange(k, '(b h) n c -> b h c n', b=B, h=self.head).view(B * self.head, self.channels_per_head, H, W)
        k = self.pool(k).view(B, self.head, self.channels_per_head, -1).transpose(2, 3).contiguous().view(B * self.head, -1, self.channels_per_head)
        v = rearrange(v, '(b h) n c -> b h c n', b=B, h=self.head).view(B * self.head, self.channels_per_head, H, W)
        v = self.pool(v).view(B, self.head, self.channels_per_head, -1).transpose(2, 3).contiguous().view(B * self.head, -1, self.channels_per_head)

        # 注意力机制
        attention_scores = torch.matmul(q, k.transpose(-2, -1))
        attention = self.softmax(attention_scores)
        weighted_values = torch.matmul(attention, v)
        weighted_values = weighted_values.view(B, self.head, self.channels_per_head, -1).transpose(2, 3).contiguous()
        weighted_values = weighted_values.view(B, C, H, W)

        return weighted_values




if __name__ == "__main__":
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    attention_module = GlobalAttention(num_channels=32, num_heads=8).to(device)
    input_tensor = torch.randn(4, 32, 64, 64).to(device)

    output = attention_module(input_tensor)
    print("Output shape:", output.shape)  # Should return a tensor with shape B*C*H*W