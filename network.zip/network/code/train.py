import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader
from Dataset import Dataset
from unmixing import mynet
import os
import time
from scipy.io import savemat

torch.manual_seed(0)
torch.cuda.manual_seed_all(0)
device = torch.device("cuda:0")

import warnings

warnings.filterwarnings("ignore")

torch.autograd.set_detect_anomaly(True)  # 启用异常检测


def adjust_learning_rate(lr, optimizer):
    """Sets the learning rate to the initial LR decayed by 10 every 20 epochs"""
    for param_group in optimizer.param_groups:
        param_group['lr'] = lr


def validate(model, criterion, mse_loss, val_loader):
    model.eval()
    total_loss, total_classification_loss, total_reconstruction_loss, total_count = 0, 0, 0, 0
    with torch.no_grad():
        for image_1, image_2, label in val_loader:
            image_1 = image_1.to(device)
            image_2 = image_2.to(device)
            label = label.to(device)

            X1, X2, out,Z3,Z6 = model(image_1, image_2)

            classification_loss = criterion(out, label.long())
            reconstruction_loss = mse_loss(X1, image_1) + mse_loss(X2, image_2)
            loss = classification_loss + 0.01 * reconstruction_loss

            total_loss += loss.item()
            total_classification_loss += classification_loss.item()
            total_reconstruction_loss += reconstruction_loss.item()
            total_count += 1

    avg_loss = total_loss / total_count
    avg_classification_loss = total_classification_loss / total_count
    avg_reconstruction_loss = total_reconstruction_loss / total_count
    return avg_loss, avg_classification_loss, avg_reconstruction_loss


def train_epoch(epoch, model, optimizer, criterion, mse_loss, train_loader, show_interval=3):
    model.train()
    classification_loss_meter, reconstruction_loss_meter, loss_meter, count_it = 0, 0, 0, 0
    for step, (image_1, image_2, label) in enumerate(train_loader):
        image_1 = image_1.to(device)
        image_2 = image_2.to(device)
        label = label.to(device)

        X1, X2, out,Z3,Z6 = model(image_1, image_2)
        # 检查模型输出是否包含 NaN
        if torch.isnan(X1).any() or torch.isnan(X2).any():
            print("NaN detected in model outputs before loss computation.")


        classification_loss = criterion(out, label.long())
        reconstruction_loss = mse_loss(X1, image_1) + mse_loss(X2, image_2)
        loss = classification_loss + 0.01 * reconstruction_loss

        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        loss_meter += loss.item()
        classification_loss_meter += classification_loss.item()
        reconstruction_loss_meter += reconstruction_loss.item()
        count_it += 1

        if step % show_interval == 0:
            print(
                f"Train - Epoch: {epoch}, Step: {step + 1}, Loss: {loss.item():.4f}, Class Loss: {classification_loss.item():.4f}, Reconst Loss: {reconstruction_loss.item():.4f}")

    return classification_loss_meter / count_it, reconstruction_loss_meter / count_it, loss_meter / count_it


def train(max_epoch, batchsz, lr, validation_interval=3):
    train_db = Dataset('Bay_Area_2013.mat', 'Bay_Area_2015.mat', 'REF.mat', 'train')
    val_db = Dataset('Bay_Area_2013.mat', 'Bay_Area_2015.mat', 'REF.mat', 'validation')
    train_data = DataLoader(train_db, batch_size=batchsz, shuffle=True, num_workers=0, pin_memory=True)
    val_data = DataLoader(val_db, batch_size=batchsz, shuffle=False, num_workers=0, pin_memory=True)

    model = mynet(B=224,M=5,N=5,P=20).to(device)
    optimizer = optim.Adam(model.parameters(), lr=lr)
    criterion = nn.CrossEntropyLoss()
    mse_loss = nn.MSELoss()
    best_val_loss = float('inf')

    for epoch in range(max_epoch):
        train_loss, train_rec_loss, train_total_loss = train_epoch(epoch, model, optimizer, criterion, mse_loss, train_data)

        if (epoch + 1) % validation_interval == 0:
            val_loss, val_class_loss, val_rec_loss = validate(model, criterion, mse_loss, val_data)
            print(
                f"Validation - Epoch: {epoch}, Loss: {val_loss:.4f}, Class Loss: {val_class_loss:.4f}, Reconst Loss: {val_rec_loss:.4f}")

            if val_class_loss < best_val_loss:

               best_val_loss = val_class_loss
               state = {
                    'epoch': epoch + 1,
                    'state_dict': model.state_dict(),
                    'best_val_loss': best_val_loss

                }
               torch.save(state, "bay_area.mdl")
               print("Saved Best Model at Epoch: ", epoch + 1)

        if (epoch + 1) % 20 == 0:
            lr /= 2
            adjust_learning_rate(lr, optimizer)
            print("Adjusted learning rate to: ", lr)


if __name__ == "__main__":
    train(200, 16, 0.001)
