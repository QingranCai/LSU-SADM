import torch
import torch.nn.functional as F
import torch.nn as nn
from multi_head_global_attention import *
from multi_head_local_attention import *
from diag_attention import *
import torch.nn.init as init
import time
device = torch.device("cuda:0")
from thop import profile, clever_format


class Up_sample1(nn.Module):
    def __init__(self, P):
        super(Up_sample1, self).__init__()
        self.denet1 = nn.ConvTranspose2d(P, P, stride=2, kernel_size=4, padding=1)
        self.denet2 = nn.ConvTranspose2d(P, P, stride=2, kernel_size=4, padding=1)
        self.relu = nn.PReLU() # 去掉 inplace 参数

    def forward(self, x):
        out = self.relu(self.denet1(x))
        out = self.denet2(out)
        return out

class Down_sample1(nn.Module):
    def __init__(self, P):
        super(Down_sample1, self).__init__()
        self.ennet1 = nn.Conv2d(P, P, stride=2, kernel_size=3, padding=1)
        self.ennet2 = nn.Conv2d(P, P, stride=2, kernel_size=3, padding=1)
        self.relu = nn.PReLU()  # 去掉 inplace 参数

    def forward(self, x):
        out = self.relu(self.ennet1(x))
        out = self.ennet2(out)
        return out

class Down_sample2(nn.Module):
    def __init__(self, P):
        super(Down_sample2, self).__init__()
        self.ennet1 = nn.Conv2d(P, P, stride=2, kernel_size=3, padding=1)
        self.relu = nn.PReLU() # 去掉 inplace 参数

    def forward(self, x):
        out = self.relu(self.ennet1(x))
        return out

class Up_sample2(nn.Module):
    def __init__(self, P):
        super(Up_sample2, self).__init__()
        self.denet1 = nn.ConvTranspose2d(P, P, stride=2, kernel_size=3, padding=1)
        self.relu = nn.PReLU()  # 去掉 inplace 参数

    def forward(self, x):
        out = self.relu(self.denet1(x))
        return out

class ReconstructionModule(nn.Module):
    def __init__(self, in_channels, out_channels):
        super(ReconstructionModule, self).__init__()
        # 第一层卷积用于特征提取
        self.conv1 = nn.Conv2d(in_channels, in_channels, kernel_size=3, padding=1)
        self.relu1 = nn.PReLU()

        # 第二层卷积用于映射回原始的通道数
        self.final_conv = nn.Conv2d(in_channels, out_channels, kernel_size=1)

    def forward(self, x):
        x = self.relu1(self.conv1(x))
        x = self.final_conv(x)
        return x

'''class DTRModule(nn.Module):
    def __init__(self, in_channels, out_channels):
        super(DTRModule, self).__init__()
        # 第一层卷积用于特征提取
        self.conv1 = nn.Conv2d(in_channels, in_channels, kernel_size=3, padding=1)
        self.relu1 = nn.PReLU()

        # 第二层卷积用于映射回原始的通道数
        self.final_conv = nn.Conv2d(in_channels, out_channels, kernel_size=1)

    def forward(self, x):
        x = self.relu1(self.conv1(x))
        x = self.final_conv(x)
        return x'''

class mynet(nn.Module):
    def __init__(self, B, M, N, P=20):
        super(mynet, self).__init__()

        self.u1 = nn.Parameter(torch.tensor([0.001]), requires_grad=True)
        self.u2 = nn.Parameter(torch.tensor([0.001]), requires_grad=True)
        self.u3 = nn.Parameter(torch.tensor([0.001]), requires_grad=True)
        self.u4 = nn.Parameter(torch.tensor([0.001]), requires_grad=True)
        self.m1 = nn.Parameter(torch.tensor([0.01]), requires_grad=True)
        self.m2 = nn.Parameter(torch.tensor([0.01]), requires_grad=True)
        self.n1 = nn.Parameter(torch.tensor([0.01]), requires_grad=True)
        self.n2 = nn.Parameter(torch.tensor([0.01]), requires_grad=True)
        self.update_factor1 = torch.tensor([1.1]) .to(device) # 更小的更新因子
        self.update_factor2 = torch.tensor([1.1]) .to(device)# 更小的更新因子
        self.w = nn.Parameter(torch.tensor([0.1]), requires_grad=True)
        self.c1 = nn.Parameter(torch.tensor([0.1]), requires_grad=True)
        self.c2 = nn.Parameter(torch.tensor([0.1]), requires_grad=True)
        self.M = M
        self.N = N
        self.P = P

        self.U1 = Up_sample1(P)
        self.V1 = Up_sample2(P)
        self.U1T = Down_sample2(P)
        self.V1T = Down_sample1(P)



        self.U2 = Up_sample1(P)
        self.V2 = Up_sample2(P)
        self.U2T = Down_sample2(P)
        self.V2T = Down_sample1(P)

        '''self.U1 = Up_sample1(P)
        self.V1 = nn.Conv2d(P, P, 1)
        self.U1T = nn.Conv2d(P, P, 1)
        self.V1T = Down_sample1(P)

        self.U2 = Up_sample1(P)
        self.V2 = nn.Conv2d(P, P, 1)
        self.U2T = nn.Conv2d(P, P, 1)
        self.V2T = Down_sample1(P)'''

        self.R1 = nn.Conv2d(P,P,1)
        self.D1T = nn.Conv2d(B,P,1)
        self.R2 = nn.Conv2d(P,P,1)
        self.D2T = nn.Conv2d(B,P,1)

        self.D1 = ReconstructionModule(P,B)
        self.D2 = ReconstructionModule(P,B)

        self.softmax = nn.Softmax(dim=1)
        self.relu = nn.PReLU()  # 可选使用 LeakyReLU

        self.diagattention1 = AdaptiveDiagonalEmphasis(channels=P, strength=10, base_decay=0.8)
        self.diagattention2 = AdaptiveDiagonalEmphasis(channels=P, strength=10, base_decay=0.8)
        self.localattention = LocalAttention(num_channels=P*2, num_heads=8)
        self.globalattention = GlobalAttention(num_channels=P*2, num_heads=8)

        self.classifier = nn.Sequential(
            nn.Linear(242 * P, 256),
            nn.PReLU(),  # 可选使用 LeakyReLU
            nn.Linear(256, 2)
        )

        self._initialize_weights()

    def _initialize_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d) or isinstance(m, nn.ConvTranspose2d):
                init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='relu')
                if m.bias is not None:
                    init.constant_(m.bias, 0)
            elif isinstance(m, nn.Linear):
                init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='relu')
                init.constant_(m.bias, 0)

    def forward(self, T1, T2):
        #T1的丰度
        Z1 = self.D1T(T1)
        Z2 = self.D1T(T1)
        #Z3 = self.D1T(T1)
        #T2的丰度
        Z4 = self.D2T(T2)
        Z5 = self.D2T(T2)
        #Z6 = self.D2T(T2)
        #T1辅助变量
        Y1 = torch.zeros_like(Z1)
        Y2 = torch.zeros_like(Z1)
        # T2辅助变量
        Y3 = torch.zeros_like(Z1)
        Y4 = torch.zeros_like(Z1)

        #先对T1、T2进行一次Z3的更新
        Z3 = self.R1(self.D1T(T1) - Y1 - Y2 + self.u1 * Z1 + self.u2 * Z2)
        Z6 = self.R2(self.D2T(T2) - Y3 - Y4 + self.u3 * Z4 + self.u4 * Z5)

        eps = 1e-6  # 添加一个小常数以防止除以零

        for i in range(self.M):
            #T1更新Z1
            Z1 = self.V1(self.U1T(Z3 + 1 / (self.u1 + eps) * Y1))
            Z1 = self.relu(Z1 - self.n1)
            Z1 = self.diagattention1(Z1)
            Z1 = self.V1T(self.U1(Z1))
            #T2更新Z1
            Z4 = self.V2(self.U2T(Z6 + 1 / (self.u3 + eps) * Y3))
            Z4 = self.relu(Z4 - self.n2)
            Z4 = self.diagattention2(Z4)
            Z4 = self.V2T(self.U2(Z4))

            # T1更新Z2
            Z2_intermediate = Z3 + (1 / (self.u2 + eps)) * Y2 - self.m1
            Z2 = self.relu(Z2_intermediate)
            out1 = torch.where((Z3 + 1 / (self.u2 + eps) * Y2) < 0, torch.ones_like(Z2) * -1, torch.ones_like(Z2))
            Z2 = Z2 * out1
            #T2更新Z2
            Z5_intermediate = Z6 + (1 / (self.u4 + eps)) * Y4 - self.m2
            Z5 = self.relu(Z5_intermediate)
            out2 = torch.where((Z6 + 1 / (self.u4 + eps) * Y4) < 0, torch.ones_like(Z5) * -1, torch.ones_like(Z5))
            Z5 = Z5 * out2
            #T1更新Z3
            Z3 = self.R1(self.D1T(T1) - Y1 - Y2 + self.u1 * Z1 + self.u2 * Z2)

            #T2更新Z3
            Z6 = self.R2(self.D2T(T2) - Y3 - Y4 + self.u3 * Z4 + self.u4 * Z5)



            # T1、T2更新辅助变量
            Y1 = torch.add(Y1, self.u1 * (Z3 - Z1))
            Y2 = torch.add(Y2, self.u2 * (Z3 - Z2))
            Y3 = torch.add(Y3, self.u3 * (Z6 - Z4))
            Y4 = torch.add(Y4, self.u4 * (Z6 - Z5))

            # 用 detach 来处理参数更新，避免 inplace 操作
            '''with torch.no_grad():
                self.u1.data *= self.update_factor1
                self.u2.data *= self.update_factor1
                self.u3.data *= self.update_factor2
                self.u4.data *= self.update_factor2



            # 限制u1、u2、u3、u4的值在合理范围内
            self.u1.data = torch.clamp(self.u1.data, min=1e-6, max=1e3)
            self.u2.data = torch.clamp(self.u2.data, min=1e-6, max=1e3)
            self.u3.data = torch.clamp(self.u3.data, min=1e-6, max=1e3)
            self.u4.data = torch.clamp(self.u4.data, min=1e-6, max=1e3)'''

        # 限制条件
        Z3 = self.softmax(Z3)
        Z6 = self.softmax(Z6)

        #重构
        X_hat1 = self.D1(Z3)
        X_hat2 = self.D2(Z6)

        #初步获得差异图
        #Z_change = torch.abs(Z3 - Z6)
        Z_change=torch.concat([Z3,Z6],dim=1)
        V = torch.zeros_like(Z_change)

        #差异图迭代更新
        for i in range(self.N):
            V1 = self.w * V
            V2 = self.c1 * torch.rand(1).item() * (self.localattention(Z_change) - Z_change)
            V3 = self.c2 * torch.rand(1).item() * (self.globalattention(Z_change) - Z_change)
            V = V1 + V2 + V3
            Z_change = torch.add(Z_change, V)

        Z_change = Z_change.view(Z_change.shape[0], -1)
        out = self.classifier(Z_change)
        return X_hat1, X_hat2, out,Z3,Z6

if __name__ == "__main__":
    B = 64
    M = 5
    N = 5
    X1 = torch.randn(4, B,11,11).to(device)
    X2 = torch.randn(4, B,11,11).to(device)

    model = mynet(B, M, N).to(device)
    _,_,y=model(X1,X2)
    print(y.shape)


