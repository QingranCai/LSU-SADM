import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader
from Dataset import Dataset
from unmixing import mynet
import os
import time
from scipy.io import savemat

device = torch.device("cuda:0")

def test(model):
    model.eval()
    checkpoint = torch.load('bay_area.mdl')
    model.load_state_dict(checkpoint['state_dict'])

    db = Dataset('Bay_Area_2013.mat', 'Bay_Area_2015.mat', 'REF.mat', 'test')

    test_loader = DataLoader(db, batch_size=16, shuffle=False)
    if not os.path.exists('result'):
        os.makedirs('result')

    output = np.zeros((600, 500))
    start = time.time()

    with torch.no_grad():
        for step, (image_1, image_2, h, w) in enumerate(test_loader):
            image_1 = image_1.type(torch.float32).to(device)
            image_2 = image_2.type(torch.float32).to(device)
            torch.cuda.synchronize()
            X1,X2,Sout = model(image_1, image_2)
            output[h.numpy(), w.numpy()] = Sout.argmax(dim=1).detach().cpu().numpy() + 1

            print(step)


    filename = "result/bay_area.mat"
    savemat(filename, {"data": output})

    end = time.time()
    print("running time:", end - start)

if __name__ == "__main__":
    model = mynet(B=224,M=5,N=5).to(device)
    test(model)