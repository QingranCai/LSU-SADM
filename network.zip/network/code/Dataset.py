
import numpy as np
import torch
import torch.nn as nn
from scipy.io import loadmat
import cv2 as cv
from torch.utils.data import DataLoader
import os
import random

class Dataset(nn.Module):
    def __init__(self, name1, name2, REF, mode, padding=5):
        super(Dataset, self).__init__()
        self.mode = mode
        self.filename_T1 = name1
        self.filename_T2 = name2
        self.REF = REF
        self.padding = padding
        self.image_T1 = loadmat(os.path.join(self.filename_T1))['HypeRvieW']
        self.image_T2 = loadmat(os.path.join(self.filename_T2))['HypeRvieW']
        self.image_REF = loadmat(os.path.join(self.REF))['HypeRvieW']
        self.image_T1 = (self.image_T1 - np.mean(self.image_T1)) / np.std(self.image_T1)
        self.image_T2 = (self.image_T2 - np.mean(self.image_T2)) / np.std(self.image_T2)

        self.padding_image_T1 = cv.copyMakeBorder(self.image_T1, self.padding, self.padding, self.padding, self.padding, cv.BORDER_REFLECT)
        self.padding_image_T2 = cv.copyMakeBorder(self.image_T2, self.padding, self.padding, self.padding, self.padding, cv.BORDER_REFLECT)
        self.ht, self.wt = self.image_T1.shape[0], self.image_T1.shape[1]
        all_numt = self.ht * self.wt
        self.whole_pointt = self.image_REF.reshape(1, all_numt)
        random.seed(1)

        # Identify changed and unchanged points
        T_Changed_p = list(np.where(self.whole_pointt[0] == 1)[0])
        T_NChanged_p = list(np.where(self.whole_pointt[0] == 2)[0])
        random.shuffle(T_Changed_p)
        random.shuffle(T_NChanged_p)

        # Select 1% of total data points
        selected_points = random.sample(T_Changed_p, int(0.01 * len(T_Changed_p))) + random.sample(T_NChanged_p,
                                                                                                    int(0.01 * len(
                                                                                                        T_NChanged_p)))
        random.shuffle(selected_points)

        # Split into 80% train and 20% validation
        num_train = int(0.9 *  len(selected_points))
        #num_train =  len(selected_points)
        if self.mode == "train":
            self.random_pointT = selected_points[:num_train]
        elif self.mode == "validation":
            self.random_pointT = selected_points[num_train:]
        elif self.mode == "test":
            self.random_pointT = list(np.where(self.whole_pointt[0] == 1)[0]) + list(np.where(self.whole_pointt[0] == 2)[0])

    def __len__(self):
        return len(self.random_pointT)

    def __getitem__(self, index):
        original_i = int((self.random_pointT[index] / self.wt))
        original_j = (self.random_pointT[index] - original_i * self.wt)
        new_i = original_i + self.padding
        new_j = original_j + self.padding

        image_1 = self.padding_image_T1[new_i - self.padding: new_i + self.padding + 1, new_j - self.padding: new_j + self.padding + 1, :].transpose(2, 0, 1)
        image_2 = self.padding_image_T2[new_i - self.padding: new_i + self.padding + 1, new_j - self.padding: new_j + self.padding + 1, :].transpose(2, 0, 1)


        image_1 = torch.tensor(image_1.copy(), dtype=torch.float32)
        image_2 = torch.tensor(image_2.copy(), dtype=torch.float32)
        label = self.image_REF[original_i, original_j] - 1

        if self.mode == "train" or self.mode == "validation":
            return image_1, image_2, label
        else:
            return image_1, image_2, original_i, original_j



# Example usage
if __name__ == "__main__":
    db_train = Dataset('Bay_Area_2013.mat', 'Bay_Area_2015.mat', 'REF.mat', 'train')
    db_validation = Dataset('Bay_Area_2013.mat', 'Bay_Area_2015.mat', 'REF.mat', 'validation')
    train_data = DataLoader(db_train, batch_size=16, shuffle=True)
    validation_data = DataLoader(db_validation, batch_size=16, shuffle=True)
    for step, data in enumerate(train_data):
        image_1, image_2, label = data
        print(f"Train - Step: {step+1}, Image 1 Shape: {image_1.shape}, Image 2 Shape: {image_2.shape}")
